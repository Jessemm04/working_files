from flask import Flask, render_template, request, redirect, flash, session, url_for
from datetime import datetime, date
from flask_wtf import FlaskForm
import sqlite3
from wtforms import StringField, SubmitField, TextAreaField, PasswordField, SelectMultipleField, SelectField
from wtforms.fields.html5 import DateField # see https://stackoverflow.com/questions/26057710/datepickerwidget-with-flask-flask-admin-and-wtforms
from wtforms.validators import DataRequired, URL, Optional, InputRequired

import random

app = Flask(__name__)

app.config['SECRET_KEY'] = 'ddksididkdkdl'

#connect to database
con = sqlite3.connect('videos.db',check_same_thread=False)
con.row_factory = sqlite3.Row
cur = con.cursor()

### Form models ####

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')

class VideoSubmitForm(FlaskForm):
    topic = SelectField('Topic', validators=[DataRequired()])
    title = StringField('Title', validators=[DataRequired()])
    link = StringField('Link', validators=[DataRequired(), URL()])
    submit = SubmitField('Submit')


########## routes ##########


@app.route('/')
@app.route('/index', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        if session['username']:
            if session['staff_code']:
                sc = session['staff_code']
                print(sc)

                sql = """
                    select staff_code
                    from staff_classes
                    where staff_code = ?;
                    """

                cur.execute(sql, (sc,))
                result = cur.fetchall()

                # if len(result) == 1:
                #     session['staff_code'] = result[0][0]
                #     session['subject_code'] = result[0][1]
                #     print(result)
                return render_template('index.html', title='Index', subclass=result)
            else:
                pass

            # if len(result) == 1:
            #     session['staff_code'] = result[0][0]
            #     session['staff_class']= result[0][1]
            # else:
            #     flash('something went wrong... :/')
            #

# sql = """
#                 select video_id, title, video_link
#                 from video_details
#                 where video_id in (
#                     select video_id
#                     from videos
#                     where topic_id in (
#                         select topic_id
#                         from topics
#                         where subject_code in (
#                             select subject_code
#                             from users u, staff_classes s, classes c
#                             where u.staff_code = s.staff_code
#                             and s.subject_code = c.subject_code
#                             and staff_code = ?;
#                             """
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            un = form.username.data
            pw = form.password.data

            sql = """
            select *
            from users
            where username = ?
            and password = ?;
            """
            cur.execute(sql,(un,pw))
            result = cur.fetchall()

            if len(result) == 1:
                session['username'] = result[0][0]
                session['firstname'] = result[0][2]
                session['lastname'] = result[0][3]
                session['teacher'] = result[0][4]
                if session['teacher']:
                    session['staff_code'] = result[0][5]
                return redirect(url_for('index'))
            else:
                flash('Username or password is incorrect, try again')
        else:
            flash('Something missing... :/')
    return render_template('login.html', title='Login', form=form)

@app.route('/')
@app.route('/video')
def video():
    # form = VideoSubmitForm
    # topics = []
    #
    # sql = """
    # select *
    # from topics;
    # """
    # cur.execute(sql,())
    # result = cur.fetchall()
    # topics.append(result)
    #
    # form.topic.choices = topics
    # if request.method == 'POST':
    #     if form.validate_on_submit():
    #         topic = form.topic.data
    #         title = form.title.data
    #         link = form.link.data
    #         date_rg = datetime.datetime.now()
    #
    #         sql = """
    #         insert
    #         into videos (topic_id, title, link, date_submitted)
    #         values (?,?,?,?,?);
    #         """
    #         try:
    #             cur.execute(sql,(topic, title, link, date_rg))
    #             con.commit()
    #         except:
    #             flash('Oops... Something went wrong! Check the values, and try again')
    #         else:
    #             flash('Account Registered Successfully')
    #             session['topic'] = topic
    #             session['title'] = title
    #             session['link'] = link
    #             return redirect(url_for('video'))


    return render_template('video.html')
# , form=form)
@app.route('/logout')
def logout():
    if session['username']:
        # clear out the session
        session['username'] = None
        session['firstname'] = None
        session['lastname'] = None
        session['teacher'] = None
        session['staff_code'] = None

        flash("You have successfully logged out")
    return redirect(url_for('index'))

if __name__ == '__main__':
    host = '127.0.0.1'
    port = 8080
    app.run(host, port, debug=True)
